### Differences:

* removed unnecessary info in open
* changed company to address line 3
* added required
* better types
* added for=""
* hid a lot of label text but kept label to keep touch target large and make sure it plays nice with screen readers

* could use something like creditcard.js, https://creditcardjs.com/

* two inputs, one label w/expiration date

* more generic shipping address
* thought about regex'ing the address, but realized that foreign addresses are probably pretttttty different.

http://www.coolfields.co.uk/2011/04/accessible-forms-should-every-input-have-a-label/