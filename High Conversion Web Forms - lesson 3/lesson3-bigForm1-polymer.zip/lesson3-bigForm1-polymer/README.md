To install and run the Polymer checkout form:

1. Install [npm](https://www.npmjs.com/), [bower](http://bower.io/) and [gulp](http://gulpjs.com/) if you haven't already
2. Run `npm install`
3. Run `bower install`
4. Host over `localhost` and open `dest/index.html` in your browser
5. As you make your edits to the files in `src/`, use `gulp watch` to watch for changes and rebuild to `dest/`.